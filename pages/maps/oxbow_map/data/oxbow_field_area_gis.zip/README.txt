Oxbow Field Area - Plant Observation Data
Prepared for the City of Pocatello
Generated 2026-08-26

CONTENTS
    oxbow_field_area.gdb        Esri File Geodatabase (ArcGIS Pro)
    oxbow_field_area.gpkg       OGC GeoPackage (QGIS, ArcGIS Pro, others)
    field_area.geojson          Field area boundary
    plant_observations.geojson  Plant observations
    species_summary.csv         One row per species
    oxbow_verify_map.html       Standalone interactive map -- double-click to
                                open in any web browser. No GIS software needed.

    The .gdb and .gpkg each contain the same three layers: field_area
    (polygon), plant_observations (point), and species_summary (table).
    The .geojson and .csv files are those same three layers standalone.

COORDINATE SYSTEM
    WGS 84 geographic (EPSG:4326). Reproject to your working CRS as needed
    (Idaho State Plane East / NAD83(2011) is EPSG:6440).

DATA SOURCE
    Plant observations come from the iNaturalist API (api.inaturalist.org),
    kingdom Plantae, filtered to verifiable observations whose coordinates
    fall inside the field area boundary. Both research-grade and
    needs-ID observations are included; use the quality_grade field to
    filter to research-grade only (51 of 99 observations).

SUMMARY
    99 observations, 72 distinct taxa.

    Invasive        10 species
    Native          42 species
    Non-Native       3 species
    Not Assessed     9 species
    Noxious          8 species

FIELD NOTES
    status                  Native / Non-Native / Invasive / Noxious, joined
                            from the project's species_status.csv. "Not Assessed"
                            means the taxon is not yet in that list.
    coord_obscured          1 where iNaturalist obscured the coordinates
                            (sensitive taxa or user privacy setting). Those
                            points are randomized within roughly 0.2 degrees
                            and should not be treated as field-accurate.
    positional_accuracy_m   Observer-reported GPS accuracy in meters, where given.
    captive                 1 where the observer flagged the plant as
                            planted or cultivated rather than wild.
    taxon_rank              Not every observation is identified to species;
                            some are genus- or family-level.

    Observation content on iNaturalist is licensed per-record; see the
    license field and inat_url for each observation.

TAXA NOT YET IN species_status.csv (9)
    Boraginaceae
    Brassicaceae
    Brassicoideae
    Bryophyta
    Geranium
    Liliopsida
    Magnoliopsida
    Potentilla
    Rosa
